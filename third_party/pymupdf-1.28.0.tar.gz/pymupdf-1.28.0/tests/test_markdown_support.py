import pymupdf
import os
import textwrap


def test_archive_markdown():
    """Test Archive support."""
    if pymupdf.mupdf_version_tuple < (1, 28, 0):
        print("no testing on MuPDF < 1.28.0")
        return

    path = os.path.abspath(f"{__file__}/../../tests/resources")
    md = b"![](nur-ruhig.jpg)\n\n**A referenced image.**"
    md_doc = pymupdf.open(stream=md, filetype="md", archive=path)
    pdfdata = md_doc.convert_to_pdf()
    doc = pymupdf.open(stream=pdfdata)
    page = doc[0]
    images = page.get_image_info()
    assert len(images) == 1

def test_archive_links():
    """Create an internal and an external link and confirm
    that they are correctly converted to PDF links."""
    if pymupdf.mupdf_version_tuple < (1, 28, 0):
        print("no testing on MuPDF < 1.28.0")
        return

    md = """Some text containing an external [link](http://www.google.com) to Google.
    Now an internal link to a header in this document: [Some Header](#some-header). The header is here:

    <h2 id="some-header">Some Header</h2>

    Some text following the header.
    """
    md_doc = pymupdf.open(stream=md.encode(), filetype="md")
    pdfdata = md_doc.convert_to_pdf()
    doc = pymupdf.open(stream=pdfdata)
    page = doc[0]
    links=page.get_links()
    assert len(links) == 2
    assert links[0]["uri"] == "http://www.google.com"
    assert links[0]["kind"] == pymupdf.LINK_URI
    assert links[1]["kind"] == pymupdf.LINK_GOTO


def test_markdown_style():
    print()
    if pymupdf.mupdf_version_tuple < (1, 28):
        print('test_markdown_style(): not running because mupdf<1.28.')
        return
    
    font = pymupdf.Font("tiro")
    arch = pymupdf.Archive(font.buffer, "tiro")

    css = """@font-face {font-family: sans-serif; src: url(tiro);}"""
    md = "Overriding sans-serif with Times-Roman."
    for use_css in 0, 1:
        md_doc = pymupdf.open(stream=md.encode(), filetype="md", archive=arch)
        if use_css:
            md_doc.apply_css(css)  # apply the CSS to the document

        md_pdf_stream = md_doc.convert_to_pdf()
        with pymupdf.open(stream=md_pdf_stream) as pdf_doc:
            page = pdf_doc[0]
            spans = [
                s for b in page.get_text("dict")["blocks"] for l in b["lines"] for s in l["spans"]
            ]

        assert len(spans) == 1
        print(f'test_markdown_style(): {use_css=} {spans[0]["font"]=}.')
        if use_css:
            assert "Roman" in spans[0]["font"]
        else:
            assert "Roman" not in spans[0]["font"]

def test_markdown_save():
    md = textwrap.dedent('''
            # title
            
            ## section
            
            text
            ''')
    with pymupdf.open(stream=md.encode(), filetype='md') as document_md:
        out_pdf = os.path.normpath(f'{__file__}/../../tests/test_markdown_save.pdf')
        document_md.save(out_pdf)
